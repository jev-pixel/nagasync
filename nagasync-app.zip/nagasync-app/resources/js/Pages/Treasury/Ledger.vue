<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head } from '@inertiajs/vue3';
import { defineProps, } from 'vue';

defineProps({ summary: Object, byType: Array, payments: Object });

const php = (c) => '₱' + (c / 100).toLocaleString('en-PH', { minimumFractionDigits: 2 });
const badge = {
    pending: 'bg-yellow-100 text-yellow-800', paid: 'bg-green-100 text-green-800',
    failed: 'bg-red-100 text-red-800', expired: 'bg-gray-200 text-gray-700', refunded: 'bg-blue-100 text-blue-800',
};
</script>

<template>
    <Head title="Treasury Ledger" />
    <AuthenticatedLayout>
        <template #header><h2 class="text-xl font-semibold text-gray-800">Treasury Ledger</h2></template>

        <div class="mx-auto max-w-7xl space-y-6 p-6">
            <div class="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
                <div class="rounded-lg bg-white p-4 shadow"><p class="text-xs text-gray-500">Gross collected</p><p class="text-xl font-bold">{{ php(summary.gross) }}</p></div>
                <div class="rounded-lg bg-white p-4 shadow"><p class="text-xs text-gray-500">Municipal collections</p><p class="text-xl font-bold text-green-600">{{ php(summary.collected) }}</p></div>
                <div class="rounded-lg bg-white p-4 shadow"><p class="text-xs text-gray-500">Convenience fees</p><p class="text-xl font-bold">{{ php(summary.fees) }}</p></div>
                <div class="rounded-lg bg-white p-4 shadow"><p class="text-xs text-gray-500">Collected today</p><p class="text-xl font-bold">{{ php(summary.today) }}</p></div>
                <div class="rounded-lg bg-white p-4 shadow"><p class="text-xs text-gray-500">Pending</p><p class="text-xl font-bold text-yellow-600">{{ summary.pending }}</p></div>
                <div class="rounded-lg bg-white p-4 shadow"><p class="text-xs text-gray-500">Failed</p><p class="text-xl font-bold text-red-600">{{ summary.failed }}</p></div>
            </div>

            <div class="rounded-lg bg-white p-5 shadow">
                <h3 class="mb-3 font-semibold">Collections by type (paid only)</h3>
                <div v-for="r in byType" :key="r.label" class="flex justify-between border-b py-2 text-sm last:border-0">
                    <span>{{ r.label }} <span class="text-gray-400">· {{ r.count }} payments</span></span>
                    <span class="font-medium">{{ php(r.amount) }}</span>
                </div>
                <p v-if="!byType.length" class="text-sm text-gray-500">No paid transactions yet.</p>
            </div>

            <div class="overflow-x-auto rounded-lg bg-white shadow">
                <table class="min-w-full text-sm">
                    <thead class="bg-gray-50 text-left">
                        <tr><th class="p-3">Reference</th><th class="p-3">Citizen</th><th class="p-3">Type</th>
                            <th class="p-3">Barangay</th><th class="p-3 text-right">Total</th><th class="p-3">Status</th><th class="p-3">When</th></tr>
                    </thead>
                    <tbody>
                        <tr v-for="p in payments.data" :key="p.id" class="border-t">
                            <td class="p-3 font-mono text-xs">{{ p.reference_no }}</td>
                            <td class="p-3">{{ p.citizen }}</td>
                            <td class="p-3">{{ p.label }}</td>
                            <td class="p-3">{{ p.barangay }}</td>
                            <td class="p-3 text-right">{{ php(p.total) }}</td>
                            <td class="p-3"><span :class="badge[p.status]" class="rounded px-2 py-0.5 text-xs capitalize">{{ p.status }}</span></td>
                            <td class="p-3 text-xs text-gray-500">{{ p.when }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </AuthenticatedLayout>
</template>