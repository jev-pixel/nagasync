<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, Link } from '@inertiajs/vue3';
import { defineProps, } from 'vue';

defineProps({
    openPolls: { type: Array, default: () => [] },
    canVote: { type: Boolean, default: false },
});
</script>

<template>
    <Head title="Dashboard" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">Dashboard</h2>
        </template>

        <div class="py-12">
            <div class="mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8">
                <div v-if="openPolls.length" class="rounded-lg border-l-4 border-indigo-500 bg-white p-5 shadow">
                    <h3 class="mb-2 font-semibold">Polls open for your vote</h3>
                    <ul class="divide-y text-sm">
                        <li v-for="p in openPolls" :key="p.id" class="flex items-center justify-between py-2">
                            <span>{{ p.title }} <span class="text-gray-400">· closes {{ p.closes_at }}</span></span>
                            <Link :href="route('polls.index')" class="text-indigo-600 underline">
                                {{ canVote ? 'Vote' : 'View' }}
                            </Link>
                        </li>
                    </ul>
                    <p v-if="!canVote" class="mt-2 text-xs text-amber-700">
                        To vote, your barangay must first verify you as a resident.
                    </p>
                </div>

                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">You're logged in!</div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>