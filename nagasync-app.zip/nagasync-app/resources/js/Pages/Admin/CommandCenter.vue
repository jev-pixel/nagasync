<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, router } from '@inertiajs/vue3';
import { computed, defineProps, onMounted, onUnmounted, ref } from 'vue';

const props = defineProps({
    statuses: Object, total: Number, avgHours: Number,
    byBarangay: Array, trend: Array, activity: Array, operations: Object,
});

const cards = [
    ['pending', 'Pending', 'text-yellow-600'],
    ['processing', 'Processing', 'text-blue-600'],
    ['approved', 'Approved', 'text-green-600'],
    ['rejected', 'Rejected', 'text-red-600'],
    ['revoked', 'Revoked', 'text-gray-600'],
];

const lastUpdated = ref(new Date());
let timer;
onMounted(() => {
    timer = setInterval(() => {
        if (document.hidden) return; // don't poll in background tabs
        router.reload({
            preserveScroll: true, preserveState: true,
            onSuccess: () => (lastUpdated.value = new Date()),
        });
    }, 10000);
});
onUnmounted(() => clearInterval(timer));

const maxTrend = computed(() => Math.max(1, ...props.trend.map((t) => t.total)));
const maxBgy = computed(() => Math.max(1, ...props.byBarangay.map((b) => b.total)));
const php = (c) => '₱' + (c / 100).toLocaleString('en-PH', { minimumFractionDigits: 2 });
</script>

<template>
    <Head title="Command Center" />
    <AuthenticatedLayout>
        <template #header>
            <div class="flex items-center justify-between">
                <h2 class="text-xl font-semibold text-gray-800">Command Center</h2>
                <span class="flex items-center text-xs text-gray-500">
                    <span class="mr-2 h-2 w-2 animate-pulse rounded-full bg-green-500"></span>
                    Live · updated {{ lastUpdated.toLocaleTimeString() }}
                </span>
            </div>
        </template>

        <div class="mx-auto max-w-7xl space-y-6 p-6">
            <!-- KPI cards -->
            <div class="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-7">
                <div class="rounded-lg bg-white p-4 shadow">
                    <p class="text-xs text-gray-500">Total requests</p>
                    <p class="text-2xl font-bold">{{ total }}</p>
                </div>
                <div v-for="[key, label, color] in cards" :key="key" class="rounded-lg bg-white p-4 shadow">
                    <p class="text-xs text-gray-500">{{ label }}</p>
                    <p :class="color" class="text-2xl font-bold">{{ statuses[key] }}</p>
                </div>
                <div class="rounded-lg bg-white p-4 shadow">
                    <p class="text-xs text-gray-500">Avg. time to issue</p>
                    <p class="text-2xl font-bold">{{ avgHours ?? '-' }}<span class="text-sm font-normal"> hrs</span></p>
                </div>
            </div>

            <!-- Operations overview -->
            <div class="grid gap-4 md:grid-cols-3">
                <div class="rounded-lg bg-white p-5 shadow">
                    <h3 class="mb-1 font-semibold">Emergencies</h3>
                    <p :class="operations.emergencies.active ? 'text-red-600' : 'text-green-600'" class="text-3xl font-bold">
                        {{ operations.emergencies.active }}
                    </p>
                    <p class="text-xs text-gray-500">awaiting response</p>
                    <dl class="mt-3 space-y-1 text-sm">
                        <div class="flex justify-between"><dt class="text-gray-500">Open (incl. dispatched)</dt><dd>{{ operations.emergencies.open }}</dd></div>
                        <div class="flex justify-between"><dt class="text-gray-500">Raised today</dt><dd>{{ operations.emergencies.today }}</dd></div>
                        <div class="flex justify-between"><dt class="text-gray-500">Avg. response</dt>
                            <dd>{{ operations.emergencies.avgAckMinutes ?? '-' }} min</dd></div>
                    </dl>
                </div>

                <div class="rounded-lg bg-white p-5 shadow">
                    <h3 class="mb-1 font-semibold">Payments today</h3>
                    <p class="text-3xl font-bold">{{ php(operations.payments.grossToday) }}</p>
                    <p class="text-xs text-gray-500">{{ operations.payments.paidToday }} paid transactions</p>
                    <dl class="mt-3 space-y-1 text-sm">
                        <div class="flex justify-between"><dt class="text-gray-500">Pending</dt><dd>{{ operations.payments.pending }}</dd></div>
                    </dl>
                </div>

                <div class="rounded-lg bg-white p-5 shadow">
                    <h3 class="mb-1 font-semibold">Market alerts</h3>
                    <p :class="operations.market.flagged.length ? 'text-red-600' : 'text-green-600'" class="text-3xl font-bold">
                        {{ operations.market.available ? operations.market.flagged.length : '-' }}
                    </p>
                    <p class="text-xs text-gray-500">
                        {{ operations.market.available ? 'commodities flagged' : 'analysis unavailable' }}
                    </p>
                    <ul class="mt-3 space-y-1 text-sm">
                        <li v-for="f in operations.market.flagged" :key="f.commodity + f.unit" class="flex justify-between">
                            <span>{{ f.commodity }}</span>
                            <span class="text-red-600">{{ f.status === 'over_srp' ? 'Above SRP' : 'Unusually high' }}</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="grid gap-6 lg:grid-cols-2">
                <!-- 14-day trend -->
                <div class="rounded-lg bg-white p-5 shadow">
                    <h3 class="mb-4 font-semibold">Requests, last 14 days</h3>
                    <div class="flex h-40 items-end gap-1">
                        <div v-for="t in trend" :key="t.day" class="flex h-full flex-1 flex-col items-center justify-end">
                            <span class="mb-1 text-[10px] text-gray-500">{{ t.total || '' }}</span>
                            <div class="w-full rounded-t bg-indigo-500"
                                 :style="{ height: (t.total / maxTrend) * 80 + '%', minHeight: t.total ? '4px' : '1px' }"></div>
                        </div>
                    </div>
                    <div class="mt-1 flex justify-between text-[10px] text-gray-400">
                        <span>{{ trend[0].day }}</span><span>{{ trend[trend.length - 1].day }}</span>
                    </div>
                </div>

                <!-- By barangay -->
                <div class="rounded-lg bg-white p-5 shadow">
                    <h3 class="mb-4 font-semibold">Top barangays by requests</h3>
                    <div v-for="b in byBarangay" :key="b.name" class="mb-2">
                        <div class="flex justify-between text-xs"><span>{{ b.name }}</span><span>{{ b.total }}</span></div>
                        <div class="h-2 rounded bg-gray-100">
                            <div class="h-2 rounded bg-emerald-500" :style="{ width: (b.total / maxBgy) * 100 + '%' }"></div>
                        </div>
                    </div>
                    <p v-if="!byBarangay.length" class="text-sm text-gray-500">No data yet.</p>
                </div>
            </div>

            <!-- Activity feed -->
            <div class="rounded-lg bg-white p-5 shadow">
                <h3 class="mb-3 font-semibold">Recent activity</h3>
                <ul class="divide-y text-sm">
                    <li v-for="a in activity" :key="a.id" class="flex justify-between py-2">
                        <span><span class="font-medium capitalize">{{ a.action }}</span> {{ a.what }} <span class="text-gray-500">by {{ a.by }}</span></span>
                        <span class="text-gray-400">{{ a.at }}</span>
                    </li>
                </ul>
                <p v-if="!activity.length" class="text-sm text-gray-500">No activity yet.</p>
            </div>
        </div>
    </AuthenticatedLayout>
</template>