<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import Dropdown from '@/Components/Dropdown.vue';
import DropdownLink from '@/Components/DropdownLink.vue';
import ResponsiveNavLink from '@/Components/ResponsiveNavLink.vue';
import { Link, usePage } from '@inertiajs/vue3';
import { computed, ref } from 'vue';

const showingNavigationDropdown = ref(false);
const page = usePage();

const role = computed(() => page.props.auth.user.role);
const isStaff = computed(() => ['barangay_staff', 'admin'].includes(role.value));
const isResponder = computed(() => ['mdrrmo', 'admin'].includes(role.value));
const isTreasury = computed(() => ['treasury', 'admin'].includes(role.value));
const isAdmin = computed(() => role.value === 'admin');

// One place to add or move links. Visibility here is cosmetic;
// real access control is the `role` middleware on each route.
const menu = computed(() => {
    const groups = [{
        label: 'Services',
        match: ['documents.*', 'payments.*', 'emergency.*', 'market.*', 'polls.*'],
        items: [
            { label: 'My Documents', route: 'documents.index' },
            { label: 'Payments', route: 'payments.index' },
            { label: 'Emergency', route: 'emergency.index' },
            { label: 'Market', route: 'market.index' },
            { label: 'Polls', route: 'polls.index' },
        ],
    }];

    const ops = [];
    if (isStaff.value) {
        ops.push({ label: 'Document Queue', route: 'staff.documents.index' },
         { label: 'Price Entry', route: 'staff.market.index' },
         { label: 'Residents', route: 'staff.residents.index' });
    }
    if (isResponder.value) ops.push({ label: 'Dispatch', route: 'dispatch.index' });
    if (isTreasury.value) ops.push({ label: 'Treasury', route: 'treasury.payments' });
    if (ops.length) groups.push({ label: 'Operations', match: ['staff.*', 'dispatch.*', 'treasury.*'], items: ops });

    if (isAdmin.value) {
        groups.push({
            label: 'Admin', match: ['admin.*'],
            items: [
                { label: 'Command Center', route: 'admin.command-center' },
                { label: 'Manage Polls', route: 'admin.polls.index' },
            ],
        });
    }

    return groups;
});

const isActive = (patterns) => patterns.some((p) => route().current(p));

const pill = (active) => [
    'inline-flex items-center rounded-md px-3 py-2 text-sm font-medium transition duration-150 ease-in-out focus:outline-none',
    active ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700',
];
</script>

<template>
    <div>
        <div class="min-h-screen bg-gray-100">
            <nav class="border-b border-gray-100 bg-white">
                <!-- Primary Navigation Menu -->
                <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                    <div class="flex h-16 justify-between">
                        <div class="flex">
                            <!-- Logo -->
                            <div class="flex shrink-0 items-center">
                                <Link :href="route('dashboard')">
                                    <ApplicationLogo class="block h-9 w-auto fill-current text-gray-800" />
                                </Link>
                            </div>

                            <!-- Navigation Links -->
                            <div class="hidden sm:ms-6 sm:flex sm:items-center sm:gap-1">
                                <Link :href="route('dashboard')" :class="pill(route().current('dashboard'))">
                                    Dashboard
                                </Link>

                                <Dropdown v-for="g in menu" :key="g.label" align="left" width="48">
                                    <template #trigger>
                                        <button type="button" :class="pill(isActive(g.match))">
                                            {{ g.label }}
                                            <svg class="-me-0.5 ms-1 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                            </svg>
                                        </button>
                                    </template>
                                    <template #content>
                                        <DropdownLink v-for="i in g.items" :key="i.route" :href="route(i.route)">
                                            {{ i.label }}
                                        </DropdownLink>
                                    </template>
                                </Dropdown>
                            </div>
                        </div>

                        <div class="hidden sm:ms-6 sm:flex sm:items-center">
                            <!-- Settings Dropdown -->
                            <div class="relative ms-3">
                                <Dropdown align="right" width="48">
                                    <template #trigger>
                                        <span class="inline-flex rounded-md">
                                            <button
                                                type="button"
                                                class="inline-flex items-center rounded-md border border-transparent bg-white px-3 py-2 text-sm font-medium leading-4 text-gray-500 transition duration-150 ease-in-out hover:text-gray-700 focus:outline-none"
                                            >
                                                {{ $page.props.auth.user.name }}
                                                <svg class="-me-0.5 ms-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                                </svg>
                                            </button>
                                        </span>
                                    </template>

                                    <template #content>
                                        <DropdownLink :href="route('profile.edit')">Profile</DropdownLink>
                                        <DropdownLink :href="route('logout')" method="post" as="button">Log Out</DropdownLink>
                                    </template>
                                </Dropdown>
                            </div>
                        </div>

                        <!-- Hamburger -->
                        <div class="-me-2 flex items-center sm:hidden">
                            <button
                                @click="showingNavigationDropdown = !showingNavigationDropdown"
                                class="inline-flex items-center justify-center rounded-md p-2 text-gray-400 transition duration-150 ease-in-out hover:bg-gray-100 hover:text-gray-500 focus:bg-gray-100 focus:text-gray-500 focus:outline-none"
                            >
                                <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                                    <path :class="{ hidden: showingNavigationDropdown, 'inline-flex': !showingNavigationDropdown }"
                                          stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                                    <path :class="{ hidden: !showingNavigationDropdown, 'inline-flex': showingNavigationDropdown }"
                                          stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Responsive Navigation Menu -->
                <div :class="{ block: showingNavigationDropdown, hidden: !showingNavigationDropdown }" class="sm:hidden">
                    <div class="space-y-1 pb-3 pt-2">
                        <ResponsiveNavLink :href="route('dashboard')" :active="route().current('dashboard')">
                            Dashboard
                        </ResponsiveNavLink>

                        <template v-for="g in menu" :key="g.label">
                            <p class="px-4 pt-3 text-xs font-semibold uppercase tracking-wide text-gray-400">{{ g.label }}</p>
                            <ResponsiveNavLink v-for="i in g.items" :key="i.route"
                                               :href="route(i.route)" :active="route().current(i.route)">
                                {{ i.label }}
                            </ResponsiveNavLink>
                        </template>
                    </div>

                    <!-- Responsive Settings Options -->
                    <div class="border-t border-gray-200 pb-1 pt-4">
                        <div class="px-4">
                            <div class="text-base font-medium text-gray-800">{{ $page.props.auth.user.name }}</div>
                            <div class="text-sm font-medium text-gray-500">{{ $page.props.auth.user.email }}</div>
                        </div>

                        <div class="mt-3 space-y-1">
                            <ResponsiveNavLink :href="route('profile.edit')">Profile</ResponsiveNavLink>
                            <ResponsiveNavLink :href="route('logout')" method="post" as="button">Log Out</ResponsiveNavLink>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Page Heading -->
            <header class="bg-white shadow" v-if="$slots.header">
                <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
                    <slot name="header" />
                </div>
            </header>

            <!-- Page Content -->
            <main>
                <slot />
            </main>
        </div>
    </div>
</template>